/*
 * Copyright (c) 2021 Syntiant Corp.  All rights reserved.
 * Contact at http://www.syntiant.com
 *
 * This software is available to you under a choice of one of two licenses.
 * You may choose to be licensed under the terms of the GNU General Public
 * License (GPL) Version 2, available from the file LICENSE in the main
 * directory of this source tree, or the OpenIB.org BSD license below.  Any
 * code involving Linux software will require selection of the GNU General
 * Public License (GPL) Version 2.
 *
 * OPENIB.ORG BSD LICENSE
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "NDP_loadModel.h"
#include "microSDUtils.h"

#define strideSamples 384                                   // 24ms stride * 16K/s 
#define NDP10X_DSP_CONFIG_TANKADDR 0x4000c0b0U              // NDP specific address
#define NDP10X_DSP_CONFIG_TANK 0x4000c0a8U                  // NDP specific address   
#define NDP10X_BOOTRAM_REMAP 0x1fffc000U                    // NDP specific address
#define STARTINF_FW_ADDRESS_OFFSET 0xC0                    // NDP specific address

uint32_t startingFWAddress;                                 // Address for the tank pointer is extracted from NDP
uint32_t tankRead;                                          // Local variable to hold value of value read from NDP
uint32_t currentPointer;                                    // Current pointer address
char dataFileName[100];                                     // String for file to be saved 
String dataFileNumber;                                      // For automatic name generation
File myFile;                                                // file for saving data
//File myFileMain;

void saveAudioInferences(uint8_t numberOfClassifiers, uint32_t sofMaxStartingAddress){    // routine for saving softMax data before posterior filter
   if (SD.begin(SDCARD_SS_PIN)) {                           // Check if SD card inserted
      myFile = SD.open("audioInferenceData.csv", FILE_WRITE);
      myFile.println("");
      for (int i=0; i<numberOfClassifiers; i++){
         myFile.print(indirectRead(sofMaxStartingAddress+i*4));
         myFile.print(",");
      }
      startingFWAddress = indirectRead(0x1fffc0c0);
      myFile.print(indirectRead(startingFWAddress));
      myFile.print(",");
      myFile.close();
   }
}


void saveLongAudioData(int dataSavePeriodInSeconds, int currentFile, uint32_t tankAddress, uint32_t tankSize){    // routine for saving data 
   if (SD.begin(SDCARD_SS_PIN)) {                           // Check if SD card inserted
      myFile = SD.open(dataFileName, FILE_WRITE);
      myFile.remove(); // delete old file                   // Deleteting the file if already existed to avoid appending it
      myFile = SD.open(dataFileName, FILE_WRITE);
      myFile.rewind(); // go to start of file
      Serial.print("SD file opened ");
      Serial.println(dataFileName);
   }
   else{
      Serial.println("SD file not opened ");
   }
   int samplesSaved =dataSavePeriodInSeconds* 16000;                     // Sampling rate is fixed at 16K   
   startingFWAddress = indirectRead(0x1fffc0c0);
   Serial.print("Samples to be saved ");                    // length of the data to be saved
   Serial.println(samplesSaved);
   currentPointer = indirectRead(startingFWAddress);        // location of current pointer in the circular buffer
   Serial.print("Current Pointer before stridePaddingAfter delay "); //pointer before waiting
   Serial.println(currentPointer);
   int n = sprintf(dataFileName, "audioData_%d.csv",currentFile);
   int16_t sampleValue;
   int32_t startingPoint = (currentPointer - 1600) ;// Saving data from before, *2 because 1 sample = 2 bytes
   if (startingPoint < 0){
    startingPoint = (currentPointer - 1600) + tankSize; //Due to circular buffer nature, the tarting point could be negative and should be adjusted
   }  
   Serial.print("Starting point (adjusting for curcular buffer if needed) ");
   Serial.println(startingPoint);
   for (int i = 0; i < (samplesSaved*2); i += 4){             // *2 becuase there are two bytes, 4 is because the read is done for 4 bytes at a time
      tankRead = indirectRead(tankAddress + (( startingPoint + i) % tankSize));
      sampleValue = tankRead & 0xffff;                        // Saving lower two bytes
      myFile.println(sampleValue);
      sampleValue = (tankRead >> 16) & 0xffff;                // Saving upper two bytes
      myFile.println(sampleValue);
      if ( (i % 1600) == 0){
         currentPointer = indirectRead(startingFWAddress); 
         //Serial.print(currentPointer);
         //Serial.print(" ");
         //Serial.print( ( startingPoint + i) % tankSize );      
         int diff =  currentPointer -  (( startingPoint + i) % tankSize);
         if (diff < 0)
            diff = diff + tankSize;
         //Serial.print(" ");
         //Serial.println( diff );
         if (diff<160){
            Serial.println(" Warning only 0.01 Second FIFO left");
         }
         if (diff<1600){
            delay(100);
         //Serial.println("waited");
         }
         if (diff> (tankSize-1600) ){
            Serial.println(" Warning terminating circular FIFO to be overwritten, margin left 0.1S");
            break;
         }
         if ( (i % 32000) == 0) {

            Serial.print("Second starting ");
            Serial.println( i / 32000);
         }
      }
    }
    myFile.close();
    Serial.println("SD file Closed ");
    currentPointer = indirectRead(startingFWAddress);         // estimating delay during the data saving process, pointer difference / 2 * 24 = elapsed time in ms
    Serial.print("Current Pointer after savind data ");
    Serial.println(currentPointer);
}

void saveAudioData(uint8_t classifier, int extrStides, int currentFile, uint32_t tankAddress, uint32_t tankSize){    // routine for saving data when invoked
   int32_t samplesSaved = strideSamples*(extrStides + 39) + 512;  // 15488 samples are required for one tensor or 0.968ms
   Serial.println(" ");   
   startingFWAddress = indirectRead(0x1fffc0c0);
   Serial.print(" Starting FW Address  ");
   Serial.println(startingFWAddress,HEX);                  // This is pointer to Tank pointer
   Serial.print("Samples to be saved ");                    // length of the data to be saved
   Serial.println(samplesSaved);
   currentPointer = indirectRead(startingFWAddress);        // location of current pointer in the circular buffer
   Serial.print("Current Pointer before stridePaddingAfter delay "); //pointer before waiting
   Serial.println(currentPointer);
   int n = sprintf(dataFileName, "data_classifier%d_%d.csv",classifier,currentFile);
   int16_t sampleValue;
   if (SD.begin(SDCARD_SS_PIN)) {                           // Check if SD card inserted
      myFile = SD.open(dataFileName, FILE_WRITE);
      myFile.remove(); // delete old file                   // Deleteting the file if already existed to avoid appending it
      myFile = SD.open(dataFileName, FILE_WRITE);
      myFile.rewind(); // go to start of file
      Serial.print("SD file opened ");
      Serial.println(dataFileName);
   }
   else{
      Serial.println("SD file not opened ");
   }
   int32_t startingPoint = (currentPointer - samplesSaved*2) ;// Saving data from before, *2 because 1 sample = 2 bytes
   if (startingPoint < 0){
    startingPoint = (currentPointer - samplesSaved*2) + tankSize; //Due to circular buffer nature, the tarting point could be negative and should be adjusted
   }
   Serial.print("Starting point (adjusting for curcular buffer if needed) ");
   Serial.println(startingPoint);
   for (int i = 0; i < (samplesSaved*2); i += 4){             // *2 becuase there are two bytes, 4 is because the read is done for 4 bytes at a time
      tankRead = indirectRead(tankAddress + (( startingPoint + i) % tankSize));
      sampleValue = tankRead & 0xffff;                        // Saving lower two bytes
      myFile.println(sampleValue);
      sampleValue = (tankRead >> 16) & 0xffff;                // Saving upper two bytes
      myFile.println(sampleValue);
    }
    myFile.close();
    Serial.println("SD file Closed ");
    currentPointer = indirectRead(startingFWAddress);         // estimating delay during the data saving process, pointer difference / 2 * 24 = elapsed time in ms
    Serial.print("Current Pointer after savind data ");
    Serial.println(currentPointer);
}

void displayOff(void){
   digitalWrite(LED_RED, LOW); 
   digitalWrite(LED_GREEN, LOW); 
   digitalWrite(LED_BLUE, LOW); 
}

void displayInference(int displayInferences, uint32_t sofMaxStartingAddress, uint8_t numberOfClassifiers){
   if (numberOfClassifiers > 3) {
      Serial.println("More than 3 classifiers, only three will be displayed with RGB colors.");
      numberOfClassifiers = 3;
   }
   for (int i=0; i<(numberOfClassifiers-1); i++){
      if (indirectRead(sofMaxStartingAddress+i*4) > 48000)
      {
         Serial.print("classifier triggered ");
         Serial.println(i);
         if (i==0) digitalWrite(LED_RED, HIGH); 
         if (i==1) digitalWrite(LED_GREEN, HIGH); 
         if (i==2) digitalWrite(LED_BLUE, HIGH); 
      }
   }
}

uint8_t extractByteValue(uint32_t input, uint8_t bytePosition){ //Fron 32 bit NDP memory map value is parsed into 8 bit uint
   uint8_t value = input >> bytePosition*8; // BytePosition can be 0, 1, 2, 3
   return value;
}
void sensorDataAndInference(int displayInferences, uint32_t sofMaxStartingAddress, int inferencesPerFile,int sensorAxes, int samplesSaved, uint8_t numberOfClassifiers, int currentFile){    // routine for saving data 
   uint32_t tankAddress = indirectRead(NDP10X_DSP_CONFIG_TANKADDR);                                       // tankAddress extracted from NDP
   uint32_t tankSize = indirectRead(NDP10X_DSP_CONFIG_TANK) >> 4;                                          // tank size extracted from NDP
   uint32_t pointerToTankPointer = indirectRead(NDP10X_BOOTRAM_REMAP + STARTINF_FW_ADDRESS_OFFSET);
   Serial.print("Tank size ");
   Serial.println(tankSize);
   int n = sprintf(dataFileName, "rawData_inference_tankptr_%d.csv",currentFile);
   int16_t sampleValue;
   int startingPoint;
   if (SD.begin(SDCARD_SS_PIN)) {                           // Check if SD card inserted
      myFile = SD.open(dataFileName, FILE_WRITE);
      myFile.remove(); // delete old file                   // Deleteting the file if already existed to avoid appending it
      myFile = SD.open(dataFileName, FILE_WRITE);
      myFile.rewind(); // go to start of file
      Serial.print("SD file opened ");
      Serial.println(dataFileName);
   }
   else{
      Serial.println("SD file not opened ");
   }
   int lastCurrentPointer=0;
   for (int inference = 0; inference < inferencesPerFile; inference++){    
      if (displayInferences>0) displayInference(displayInferences, sofMaxStartingAddress,numberOfClassifiers);
      if (( inference % 10 ) == 9) Serial.print(".");            //Printing one dot for every 10 frames or inferences
      if (( inference % 100 ) == 99) Serial.println("");           //Starting a new line
      currentPointer = indirectRead(pointerToTankPointer);  
      while(currentPointer == lastCurrentPointer){                //Waiting for tankpointer to be changed so that only one entry is printed to avoid duplication
         currentPointer = indirectRead(pointerToTankPointer);
         delay(2);
      }
      delay(10);
      lastCurrentPointer = currentPointer;
      startingPoint = currentPointer - samplesSaved*2;         // 2 is for two bytes
      if (startingPoint < 0){
         startingPoint = startingPoint + tankSize; //Due to circular buffer nature, the tarting point could be negative and should be adjusted
      }  
      for (int i = 0; i < (samplesSaved*2); i += 4){             // *2 becuase there are two bytes, 4 is because the read is done for 4 bytes at a time
         tankRead = indirectRead(tankAddress + (( startingPoint + i) % tankSize));
         sampleValue = tankRead & 0xffff;                        // Saving lower two bytes
         myFile.print(sampleValue);
         myFile.print(",");
         sampleValue = (tankRead >> 16) & 0xffff;                // Saving upper two bytes
         myFile.print(sampleValue);
         myFile.print(",");
      }
      for (int i=0; i<(1+numberOfClassifiers/4); i += 4){                  // Saving classifier values before posterior filter
         tankRead = indirectRead(0x60062310+i);
         for (int bytePosition=0; bytePosition<(numberOfClassifiers % 4); bytePosition++ ){
            myFile.print(extractByteValue(tankRead,bytePosition));
            myFile.print(",");
         }
      }
      for (int i=0; i<numberOfClassifiers; i++){                  // Saving classifier values before posterior filter
         myFile.print(indirectRead(sofMaxStartingAddress+i*4));
         myFile.print(",");
      }
      myFile.print(currentPointer);                               // Saving tankpointer
      myFile.println("");
      if (displayInferences>0) displayOff();
   }
   Serial.println("");
   myFile.close();
}

void tankAndDnnFeature( int samplesSaved, int currentFile, uint32_t tankAddress, uint32_t tankSize){    // routine for saving data 
   uint32_t dnnFeatures[360];
   int n = sprintf(dataFileName, "tankAndDnnFeature_%d.csv",currentFile);
   int8_t sampleValue8bits;
   int16_t sampleValue;
   int32_t startingPoint;
   int32_t currentPointerAtEnd;
   int32_t dnnIndex;

   if (SD.begin(SDCARD_SS_PIN)) {                           // Check if SD card inserted
      myFile = SD.open(dataFileName, FILE_WRITE);
      myFile.remove(); // delete old file                   // Deleteting the file if already existed to avoid appending it
      myFile = SD.open(dataFileName, FILE_WRITE);
      myFile.rewind(); // go to start of file
      Serial.print("SD file opened ");
      Serial.println(dataFileName);
   }
   else{
      Serial.println("SD file not opened ");
   }
   startingFWAddress = indirectRead(0x1fffc0c0);

   currentPointer = indirectRead(startingFWAddress);
   Serial.print("Starting current pointer ");
   Serial.println(currentPointer);
   uint32_t dnnStaticFeature=0x60061000;
   Serial.println("address DNN feature - 0x60061000, value");
   for (int i = 0; i < 1440 ; i += 4){
      dnnIndex = int( (i)/4 );
      dnnFeatures[dnnIndex] = indirectRead(dnnStaticFeature + i);
   }
   currentPointerAtEnd = indirectRead(startingFWAddress);
   Serial.print("Ending current pointer, ");
   Serial.println(currentPointerAtEnd);
   Serial.println("");
   for (int i = 0; i < 1440 ; i += 4){    
      dnnIndex = int( (i)/4 );
      tankRead = dnnFeatures[dnnIndex];
      sampleValue8bits = (tankRead ) & 0xff;                // Saving upper two bytes
      //myFile.print(sampleValue8bits ); 
      Serial.print( i);
      Serial.print( ", ");
      Serial.println(sampleValue8bits );
      //myFile.print(",");
      sampleValue8bits = (tankRead >> 8) & 0xff;                // Saving upper two bytes
      //myFile.print(sampleValue8bits ); 
      Serial.print( i+1);
      Serial.print( ", ");
      Serial.println(sampleValue8bits );
      //myFile.print(",");
      sampleValue8bits = (tankRead >> 16) & 0xff;                // Saving upper two bytes
      //myFile.print(sampleValue8bits ); 
      Serial.print( i+2);
      Serial.print( ", ");
      Serial.println(sampleValue8bits );
      //myFile.print(",");
      //Serial.println(tankRead);
      sampleValue8bits = (tankRead >> 24) & 0xff;                        // Saving lower two bytes
      //myFile.println(sampleValue8bits );
      Serial.print( i+3);
      Serial.print( ", ");
      Serial.println(sampleValue8bits );
      //myFile.print(",");
   }

   startingPoint = currentPointer - samplesSaved*2;         // 2 is for two bytes, Assuming current pointer is updated after each run
   if (startingPoint < 0){
      startingPoint = currentPointer + tankSize; //Due to circular buffer nature, the tarting point could be negative and should be adjusted
   } 
   for (int i = 0; i < (samplesSaved*2); i += 4){    
      tankRead = indirectRead(tankAddress + (( startingPoint + i) % tankSize));
      sampleValue = tankRead & 0xffff;                        // Saving lower two bytes
      //myFile.print(sampleValue >> 8);
      Serial.print( ( startingPoint + i) % tankSize);
      Serial.print( ", ");
      Serial.println(sampleValue >> 8);
      //myFile.print(",");
      sampleValue = (tankRead >> 16) & 0xffff;                // Saving upper two bytes
      Serial.print( ( startingPoint + i) % tankSize + 2);
      Serial.print( ", ");
      //myFile.print(sampleValue >> 8); 
      Serial.println(sampleValue >> 8 );
      //myFile.print(",");
   }

   myFile.close();
}