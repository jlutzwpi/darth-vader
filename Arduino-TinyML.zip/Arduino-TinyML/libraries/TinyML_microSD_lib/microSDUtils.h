void saveAudioInferences(uint8_t numberOfClassifiers, uint32_t sofMaxStartingAddress);
void saveAudioData(uint8_t classifier, int extrStides, int currentFile, uint32_t tankAddress, uint32_t tankSize);
void saveLongAudioData(int dataSavePeriodInSeconds, int currentFile, uint32_t tankAddress, uint32_t tankSize);
void sensorDataAndInference(int displayInferences, uint32_t sofMaxStartingAddress, int inferencesPerFile, int sensorAxes, int samplesSaved, uint8_t numberOfClassifiers, int currentFile);
void tankAndDnnFeature( int samplesSaved, int currentFile, uint32_t tankAddress, uint32_t tankSize);
