#define PORSTB 24  
#define TINYML_CS 18  
#define OSC32K_OUT_PIN 3
byte SPI_CS = TINYML_CS; 
byte FlashType[4]; 