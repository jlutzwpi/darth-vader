
void adc_enable(void);
void adc_disable(void);
void systick_enable(void);
void systick_disable(void);
void usb_serial_enable(void);
void usb_serial_disable(void);
void prep_for_sleep(void);
