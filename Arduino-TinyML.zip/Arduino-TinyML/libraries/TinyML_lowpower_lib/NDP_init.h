
void NDP_init(String model, byte tranceducer);
#define PORSTB 24  
#define TINYML_CS 18 